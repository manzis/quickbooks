

function setupClickListener(elementId, targetUrl) {
    var element = document.getElementById(elementId);
    if (element) {
      element.addEventListener("click", function (e) {
        window.location.href = targetUrl;
      });
    }
  }
setupClickListener("contactUsText", "./contact.html");
setupClickListener("loginText", "./login.html");
setupClickListener("hometext", "./home.php");
setupClickListener("homeroute", "./home.php");
setupClickListener("signUpFrame", "./signup.html");
setupClickListener("recipeBookFrame","./signup.html");
setupClickListener("userprofile", "./userProfile/userProfile.php");
setupClickListener("homeProfile", "../userLogin.php");
setupClickListener("openBook", "./bookPage/bookPage.php");
setupClickListener("backBtn", "../userLogin.php");
setupClickListener("homePage", "../userLogin.php");
setupClickListener("profileIcon", "../userProfile/userProfile.php");



function setupElementHovver(elementId) {
    var element = document.getElementById(elementId);
  
    if (element) {
      // Hover effect
      element.addEventListener("mouseover", function () {
        element.style.backgroundColor = "#f0f0f0"; // Change background color on hover
      });
  
      element.addEventListener("mouseout", function () {
        element.style.backgroundColor = ""; // Reset background color on mouseout
      });
    }
}
  

// Function to setup focus and blur actions for multiple elements
function setupFocusAndBlurActions(elementIds) {
    elementIds.forEach(function(id) {
      var element = document.getElementById(id);
      if (element) {
        // Add 'active' class when the element is focused
        element.addEventListener("focus", function() {
          this.classList.add("active");
        }, true); // Use capture to ensure the event is captured during the capturing phase
  
        // Remove 'active' class when the element loses focus
        element.addEventListener("blur", function() {
          this.classList.remove("active");
        }, true); // Use capture for the same reason
      }
    });
  }
  
  // Call the function with an array of IDs
  document.addEventListener("DOMContentLoaded", function() {
    setupFocusAndBlurActions(["email","password"]);
  });


  var authorInfoFrame = document.getElementById("authorInfoFrame");
      if (authorInfoFrame) {
        authorInfoFrame.addEventListener("click", function () {
          var anchor = document.querySelector(
            "[data-scroll-to='iconSearchRectangle']"
          );
          if (anchor) {
            anchor.scrollIntoView({ block: "start", behavior: "smooth" });
          }
        });
      }



      //handling for UserProfile //
      var icons8Edit481 = document.getElementById("editProfile");
      if (icons8Edit481) {
        icons8Edit481.addEventListener("click", function () {
          var popup = document.getElementById("framePopup");
          if (!popup) return;
          var popupStyle = popup.style;
          if (popupStyle) {
            popupStyle.display = "flex";
            popupStyle.zIndex = 100;
            popupStyle.backgroundColor = "rgba(113, 113, 113, 0.3)";
            popupStyle.alignItems = "center";
            popupStyle.justifyContent = "center";
          }
          popup.setAttribute("closable", "");
      
          var onClick =
            popup.onClick ||
            function (e) {
              if (e.target === popup && popup.hasAttribute("closable")) {
                popupStyle.display = "none";
              }
            };
          popup.addEventListener("click", onClick);
        });
      }

      function viewBook(bookId) {
        // Redirect to the book page based on the book ID
        window.location.href = './bookPage/bookPage.php?book_id=' + bookId;
    }

    //download successful event popup 
      function downloadClick(bookId) {
        // Make an AJAX request to fetch the PDF file name
        $.ajax({
            type: 'GET',
            url: '../phpHandlers/fetchDownload.php',
            data: { book_id: bookId },
            dataType: 'json',
            success: function (response) {
                if (response.status === 'success') {
                    // File name retrieved successfully, initiate the download
                    initiateDownload(response.fileName);
                } else {
                    alert('Error: ' + response.message);
                }
            },
            error: function (error) {
                console.error(error);
                alert('Error occurred while fetching PDF file name');
            }
        });

        var popup = document.getElementById("download");
        if (!popup) return;
        var popupStyle = popup.style;
        if (popupStyle) {
          popupStyle.display = "flex";
          popupStyle.zIndex = 100;
          popupStyle.backgroundColor = "rgba(113, 113, 113, 0.3)";
          popupStyle.alignItems = "center";
          popupStyle.justifyContent = "center";
        }
        popup.setAttribute("closable", "");
    
        var onClick =
          popup.onClick ||
          function (e) {
            if (e.target === popup && popup.hasAttribute("closable")) {
              popupStyle.display = "none";
            }
          };
        popup.addEventListener("click", onClick);
    }
    
    function initiateDownload(fileName) {
        // Construct the full path to the file
        var filePath = '../phpHandlers/files/' + fileName;
    
        // Create a hidden anchor element
        var downloadLink = document.createElement('a');
        downloadLink.href = filePath;
        downloadLink.download = fileName;
    
        // Append the anchor to the document
        document.body.appendChild(downloadLink);
    
        // Trigger a click event on the anchor
        downloadLink.click();
    
        // Remove the anchor from the document
        document.body.removeChild(downloadLink);

    }
    
    
      
      
    
        
      
    


      
  

      